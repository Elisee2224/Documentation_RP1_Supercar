<?php
include("bdconnect.php");
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $utilisateur = $_POST["utilisateur"];
    $motdepasse = $_POST["motdepasse"];

    $requete = "SELECT idadmin, admin, motdepasse FROM admin WHERE admin=? AND motdepasse=?";

    $stmt = mysqli_prepare($bdd, $requete);

    if (!$stmt) {
        die("Erreur de préparation de la requête : " . mysqli_error($bdd));
    }

    mysqli_stmt_bind_param($stmt, "ss", $utilisateur, $motdepasse);

    if (!mysqli_stmt_execute($stmt)) {
        die("Erreur lors de l'exécution de la requête : " . mysqli_error($bdd));
    }

    mysqli_stmt_store_result($stmt);

    if (mysqli_errno($bdd)) {
        die("Erreur lors du stockage du résultat : " . mysqli_error($bdd));
    }

    $num = mysqli_stmt_num_rows($stmt);

    if (mysqli_errno($bdd)) {
        die("Erreur lors du comptage des lignes : " . mysqli_error($bdd));
    }

    mysqli_stmt_free_result($stmt);

    if ($num == 1) {
        $_SESSION["utilisateur"] = $utilisateur;
        echo '<script>alert("Bonjour ' . $utilisateur . ' !")</script>';
        header("Refresh: 0; URL='admin_utilisateur.php'");
    } else {
        echo '<script>alert("Le nom d\'utilisateur ou le mot de passe est incorrect.")</script>';
    }

    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login form</title>
   <link rel="stylesheet" href="style/admin_css.css">
</head>
<body>
   
<div class="form-container">
   <form action="" method="post">
      <h3>login now</h3>
      <input type="email" name="utilisateur" required placeholder="enter your email">
      <input type="password" name="motdepasse" required placeholder="enter your password">
      <input type="submit" name="submit" value="login now" class="form-btn">
   </form>
</div>

</body>
</html>
