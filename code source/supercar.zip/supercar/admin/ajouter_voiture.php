<?php
include("bdconnect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $marque = $_POST['marque'];
    $modele = $_POST['modele'];
    $annee = $_POST['annee'];
    $description1 = $_POST['description1'];
    $description = $_POST['description'];
    $prix = $_POST['prix'];

    // Handle image upload
    $target_dir = "../images/"; // Image directory path
    $target_file = $target_dir . basename($_FILES["image"]["name"]);

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        $image_path = "images/" . $_FILES["image"]["name"];
        
        // Insert the new data into the database, including the image path
        $sql = "INSERT INTO voitures (marque, modele, annee, description1, description, prix, image) VALUES ('$marque', '$modele', '$annee', '$description1', '$description', '$prix', '$image_path')";
    
        if (mysqli_query($bdd, $sql)) {
            echo "Voiture créée avec succès.";
        } else {
            echo "Erreur lors de la création de la voiture : " . mysqli_error($bdd);
        }
    } else {
        echo "Error uploading the image.";
    }
}


// Display the creation form, including the image field
echo "<form method='post' action='' enctype='multipart/form-data'>";
echo "Marque: <input type='text' name='marque'><br>";
echo "Modèle: <input type='text' name='modele'><br>";
echo "Année: <input type='text' name='annee'><br>";
echo "Description courte: <textarea name='description1'></textarea><br>";
echo "Description détaillée: <textarea name='description'></textarea><br>";
echo "Prix: <input type='text' name='prix'><br>";
echo "Image: <input type='file' name='image'><br>";
echo "<input type='submit' value='Créer'>";
echo "</form>";

mysqli_close($bdd);
?>
