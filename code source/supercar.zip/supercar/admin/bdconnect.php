<?php

$host = "mysql-elisee2023.alwaysdata.net";
$login = "338020";
$pass = "MonM0tDeP@ssepourHeberger";
$bdname = "elisee2023_supercar";

$bdd = mysqli_connect($host, $login, $pass, $bdname);

if ($bdd)

{
    echo "Connexion reussie a MYSQL";
}

else

    {
        echo "Connexion non-reussite";
    }

mysqli_set_charset($bdd,"utf8");
?>
