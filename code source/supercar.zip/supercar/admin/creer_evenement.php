<?php
include("bdconnect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titre = $_POST['titre'];
    $soustitre = $_POST['soustitre'];
    $description_event = $_POST['description_event'];
    $description_info = $_POST['description_info'];

    // Gestion du téléchargement de l'image
    $target_dir = "../images/"; // Chemin d'accès images
    $target_file = $target_dir . basename($_FILES["image"]["name"]);

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        // Le fichier a été téléchargé avec succès
        $image_path = "images/" . $_FILES["image"]["name"];

        // Insérez les nouvelles données dans la base de données en utilisant les valeurs postées
        $sql = "INSERT INTO evenement (titre, soustitre, description_event, description_info, image) VALUES ('$titre', '$soustitre', '$description_event', '$description_info', '$image_path')";
    
        if (mysqli_query($bdd, $sql)) {
            echo "Événement créé avec succès.";
        } else {
            echo "Erreur lors de la création de l'événement : " . mysqli_error($bdd);
        }
    } else {
        echo "Erreur lors du téléchargement de l'image.";
    }
}

// Affichez le formulaire de création ici, y compris le champ d'image
echo "<form method='post' action='' enctype='multipart/form-data'>";
echo "Titre: <input type='text' name='titre'><br>";
echo "Sous-titre: <input type='text' name='soustitre'><br>";
echo "Description de l'événement: <textarea name='description_event'></textarea><br>";
echo "Description supplémentaire: <textarea name='description_info'></textarea><br>";
echo "Image: <input type='file' name='image'><br>";
echo "<input type='submit' value='Créer'>";
echo "</form>";

mysqli_close($bdd);
?>
