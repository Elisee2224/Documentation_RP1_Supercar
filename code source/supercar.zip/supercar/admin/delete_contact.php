<!DOCTYPE HTML>

<html>

<head>

    <meta charset="utf-8">

    <title>Admin - Contact</title>

    <link rel="stylesheet" href="">

</head>

<body>

 

<?php

include("bdconnect.php");

 

$idcontact = $_GET['id'];

$requete = "DELETE FROM contact WHERE idcontact = $idcontact";

$result = $bdd->query($requete);

 

        if ($result) {

            echo '<script>alert("Cette ligne a bien été supprimée.")</script>';

            header("Refresh: 0; URL='contact_admin.php'");

        } else {

            echo '<script>alert("Echec")</script>';

            header("Refresh: 0; URL='contact_admin.php'");

        }

?>

 

</body>

</html>