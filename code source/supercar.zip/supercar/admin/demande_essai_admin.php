<?php
include("bdconnect.php"); // connexion à la base de données.

// Requête SQL pour récupérer toutes les données de la table demande_essai
$requete = "SELECT * FROM demande_essai";

$resultat = mysqli_query($bdd, $requete);

if (!$resultat) {
    die("Erreur lors de la récupération des données : " . mysqli_error($bdd));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Demande d'essai - Admin</title>
   <link rel="stylesheet" href="style/admin_css.css">
</head>
<body>
   
<div class="container">
   <div class="content">
      <h3>Bonjour, <span>Admin</span></h3>
      <h1>Demande d'essai - Admin</h1>

      <!-- Affichage des données dans un DataGridView -->
      <table>
         <tr>
            <th>ID Essai</th>
            <th>Nom Utilisateur</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Marque</th>
            <th>Modèle</th>
            <th>Date Début Essai</th>
            <th>Date Fin Essai</th>
            <th>Heure Début Essai</th>
            <th>Heure Fin Essai</th>
            <th>Action</th>
         </tr>
         <?php
         while ($row = mysqli_fetch_assoc($resultat)) {
             echo "<tr>";
             echo "<td>" . $row['idessai'] . "</td>";
             echo "<td>" . $row['nom_utilisateur'] . "</td>";
             echo "<td>" . $row['nom'] . "</td>";
             echo "<td>" . $row['prenom'] . "</td>";
             echo "<td>" . $row['adresse_mail_client'] . "</td>";
             echo "<td>" . $row['marque'] . "</td>";
             echo "<td>" . $row['modele'] . "</td>";
             echo "<td>" . $row['date_debut_essai'] . "</td>";
             echo "<td>" . $row['date_fin_essai'] . "</td>";
             echo "<td>" . $row['heure_debut_essai'] . "</td>";
             echo "<td>" . $row['heure_fin_essai'] . "</td>";

             // Bouton Éditer
    echo "<td><a href='editer_demande.php?id=" . $row['idessai'] . "'>Éditer</a></td>";
    
    // Bouton Supprimer
    echo "<td><a href='supprimer_demande.php?id=" . $row['idessai'] . "'>Supprimer</a></td>";
    
             echo "</tr>";
         }
         ?>
      </table>
   </div>
</div>

<!-- Footer -->
<div class="container">
<div class="content">
   <a href="voiture_admin.php" class="btn">gestion voiture </a>
   <a href="evenement_admin.php" class="btn"> gestion evenement</a>
   <a href="contact_admin.php" class="btn"> gestion contact </a>
   <a href="logout.php" class="btn"> deconnexion</a>
      </div>
</div>


</body>
</html>

<?php
mysqli_free_result($resultat); // Libérer la mémoire du résultat
mysqli_close($bdd); // Fermer la connexion à la base de données
?>
