<!DOCTYPE HTML>

<html>

<head>

    <meta charset="utf-8">

    <title> Modification - Contact </title>

    <link rel="stylesheet" href="">

</head>

<body>

 

<?php

include("bdconnect.php");

 

if (isset($_GET['id'])) {

    $idcontact = $_GET['id'];

   

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $nom = $_POST["nom"];

        $prenom = $_POST["prenom"];

        $adresse_mail_contact = $_POST["adresse_mail_contact"];

        $sujet = $_POST["sujet"];

        $message = $_POST["message"];

 

        $requete = "UPDATE contact SET nom = '$nom', prenom = '$prenom', adresse_mail_contact = '$adresse_mail_contact', sujet = '$sujet', message = '$message' WHERE idcontact = $idcontact";

        $result = mysqli_query($bdd, $requete);

 

 

    }

 

    $select_query = "SELECT * FROM contact WHERE idcontact = $idcontact";

    $select_result = mysqli_query($bdd, $select_query);

    $update = mysqli_fetch_assoc($select_result);

 

        

}

?>

 

<form method="POST">

    <input type="hidden" name="id" value="<?php echo $update['idcontact']; ?>">

    <input type="text" name="nom" value="<?php echo $update['nom']; ?>">

    <input type="text" name="prenom" value="<?php echo $update['prenom']; ?>">

    <input type="text" name="adresse_mail_contact" value="<?php echo $update['adresse_mail_contact']; ?>">

    <input type="text" name="sujet" value="<?php echo $update['sujet']; ?>">

    <input type="text" name="message" value="<?php echo $update['message']; ?>">

    <input type="submit" value="Update">

</form>

 

</body>

</html>