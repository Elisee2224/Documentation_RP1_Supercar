<?php
include("bdconnect.php"); // Assurez-vous que cette ligne inclut la connexion à la base de données.

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Récupérez les données de la demande d'essai à éditer depuis la base de données
    $requete = "SELECT * FROM demande_essai WHERE idessai = $id";
    $resultat = mysqli_query($bdd, $requete);
    
    if ($resultat && mysqli_num_rows($resultat) > 0) {
        $row = mysqli_fetch_assoc($resultat);
        // Vous pouvez utiliser les données de $row pour pré-remplir un formulaire d'édition
    } else {
        echo "Demande d'essai non trouvée.";
    }
} else {
    echo "ID de demande d'essai non spécifié.";
}

// Le formulaire d'édition peut être ajouté ici
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <!-- Mettez ici vos balises meta, title, et liens vers les styles -->
</head>
<body>
   <h1>Éditer Demande d'Essai</h1>
   <form action="modifier_demande.php" method="post">
       <!-- Utilisez les données de $row pour pré-remplir le formulaire -->
       <input type="hidden" name="id" value="<?php echo $row['idessai']; ?>">
       <label for="nom_utilisateur">Nom Utilisateur:</label>
       <input type="text" name="nom_utilisateur" value="<?php echo $row['nom_utilisateur']; ?>"><br>
       
       <label for="nom">Nom:</label>
       <input type="text" name="nom" value="<?php echo $row['nom']; ?>"><br>
       
       <label for="prenom">Prénom:</label>
       <input type="text" name="prenom" value="<?php echo $row['prenom']; ?>"><br>
       
       <label for="adresse_mail_client">Adresse E-mail:</label>
       <input type="text" name="adresse_mail_client" value="<?php echo $row['adresse_mail_client']; ?>"><br>
       
       <label for="adresse_physique_client">Adresse Physique:</label>
       <input type="text" name="adresse_physique_client" value="<?php echo $row['adresse_physique_client']; ?>"><br>
       
       <label for="telephone">Téléphone:</label>
       <input type="text" name="telephone" value="<?php echo $row['telephone']; ?>"><br>
       
       <label for="marque">Marque de la Voiture:</label>
       <input type="text" name="marque" value="<?php echo $row['marque']; ?>"><br>
       
       <label for="modele">Modèle de la Voiture:</label>
       <input type="text" name="modele" value="<?php echo $row['modele']; ?>"><br>
       
       <label for="date_debut_essai">Date de Début d'Essai:</label>
       <input type="date" name="date_debut_essai" value="<?php echo $row['date_debut_essai']; ?>"><br>
       
       <label for="date_fin_essai">Date de Fin d'Essai:</label>
       <input type="date" name="date_fin_essai" value="<?php echo $row['date_fin_essai']; ?>"><br>
       
       <label for="heure_debut_essai">Heure de Début d'Essai:</label>
       <input type="time" name="heure_debut_essai" value="<?php echo $row['heure_debut_essai']; ?>"><br>
       
       <label for="heure_fin_essai">Heure de Fin d'Essai:</label>
       <input type="time" name="heure_fin_essai" value="<?php echo $row['heure_fin_essai']; ?>"><br>
       
       <input type="submit" value="Enregistrer les modifications">
   </form>
</body>
</html>

<?php
mysqli_close($bdd); // Fermez la connexion à la base de données
?>
