<?php
include("bdconnect.php");

// Exécutez la requête SQL pour récupérer les données de la table evenement
$sql = "SELECT * FROM evenement";
$result = mysqli_query($bdd, $sql);

// Vérifiez s'il y a des données à afficher
if (mysqli_num_rows($result) > 0) {
    echo "<table>";
    echo "<tr><th>idevenement</th><th>titre</th><th>soustitre</th><th>description_event</th><th>description_info</th><th>image</th><th>Actions</th></tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['idevenement'] . "</td>";
        echo "<td>" . $row['titre'] . "</td>";
        echo "<td>" . $row['soustitre'] . "</td>";
        echo "<td>" . $row['description_event'] . "</td>";
        echo "<td>" . $row['description_info'] . "</td>";
        echo "<td><img src='../" . $row['image'] . "' alt='Image de l'événement' width='100' height='100'></td>";

        // Bouton Modifier
        echo "<td><a href='modifier_evenement.php?id=" . $row['idevenement'] . "' class='btn'>Modifier</a></td>";

        // Bouton Supprimer
        echo "<td><a href='supprimer_evenement.php?id=" . $row['idevenement'] . "' class='btn'>Supprimer</a></td>";
        echo "</tr>";
    }

    // Bouton Ajouter un événement
    echo "<tr><td colspan='6'></td><td><a href='creer_evenement.php' class='btn'>Ajouter un événement</a></td></tr>";

    echo "</table>";
} else {
    echo "Aucune donnée trouvée.";
}


mysqli_close($bdd);
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Demande d'essai - Admin</title>
   <link rel="stylesheet" href="style/admin_css.css">
</head>
<body>

<!-- Footer -->
<div class="container">
<div class="content">
      <a href="demande_essai_admin.php" class="btn"> gestion demande d'essai</a>
      <a href="voiture_admin.php" class="btn">gestion voiture </a>
      <a href="contact_admin.php" class="btn"> gestion contact </a>
      <a href="logout.php" class="btn"> deconnexion</a>
      </div>
</div>

</body>