<?php
include("bdconnect.php"); // Assurez-vous que cette ligne inclut la connexion à la base de données.

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérez les données du formulaire
    $id = $_POST['id'];
    $nom_utilisateur = $_POST['nom_utilisateur'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $adresse_mail_client = $_POST['adresse_mail_client'];
    $adresse_physique_client = $_POST['adresse_physique_client'];
    $telephone = $_POST['telephone'];
    $marque = $_POST['marque'];
    $modele = $_POST['modele'];
    $date_debut_essai = $_POST['date_debut_essai'];
    $date_fin_essai = $_POST['date_fin_essai'];
    $heure_debut_essai = $_POST['heure_debut_essai'];
    $heure_fin_essai = $_POST['heure_fin_essai'];
    
    // Préparez une requête SQL pour mettre à jour les données de la demande d'essai
    $requete = "UPDATE demande_essai SET 
                nom_utilisateur = '$nom_utilisateur',
                nom = '$nom',
                prenom = '$prenom',
                adresse_mail_client = '$adresse_mail_client',
                adresse_physique_client = '$adresse_physique_client',
                telephone = '$telephone',
                marque = '$marque',
                modele = '$modele',
                date_debut_essai = '$date_debut_essai',
                date_fin_essai = '$date_fin_essai',
                heure_debut_essai = '$heure_debut_essai',
                heure_fin_essai = '$heure_fin_essai'
                WHERE idessai = $id";
    
    $resultat = mysqli_query($bdd, $requete);
    
    if ($resultat) {
        echo "mise à jour de la demande d'essai effectué avec succès ";
    } else {
        echo "Erreur lors de la mise à jour de la demande d'essai : " . mysqli_error($bdd);
    }
} else {
    echo "Accès non autorisé.";
}

mysqli_close($bdd); // Fermez la connexion à la base de données
?>
