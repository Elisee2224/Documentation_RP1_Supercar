<?php
include("bdconnect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idevenement = $_POST['idevenement'];
    $titre = $_POST['titre'];
    $soustitre = $_POST['soustitre'];
    $description_event = $_POST['description_event'];
    $description_info = $_POST['description_info'];

    // Gestion du téléchargement de la nouvelle image (si elle est modifiée)
    if ($_FILES["image"]["error"] === 0) {
        $target_dir = "../images/"; //  chemin d'accès pour les images
        $target_file = $target_dir . basename($_FILES["image"]["name"]);

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            // Le fichier a été téléchargé avec succès
            $image_path = "images/" . $_FILES["image"]["name"];
        } else {
            echo "Erreur lors du téléchargement de la nouvelle image.";
            exit;
        }
    }

    // Mettez à jour les données dans la base de données, y compris l'image si elle a été modifiée
    $sql = "UPDATE evenement SET titre = '$titre', soustitre = '$soustitre', description_event = '$description_event', description_info = '$description_info'";
    
    if (isset($image_path)) {
        $sql .= ", image = '$image_path'";
    }
    
    $sql .= " WHERE idevenement = $idevenement";

    if (mysqli_query($bdd, $sql)) {
        echo "Événement mis à jour avec succès.";
    } else {
        echo "Erreur lors de la mise à jour de l'événement : " . mysqli_error($bdd);
    }
}

// Récupérez les détails de l'événement à partir de la base de données pour préremplir le formulaire de modification
if (isset($_GET['id'])) {
    $idevenement = $_GET['id'];
    
    $sql = "SELECT * FROM evenement WHERE idevenement = $idevenement";
    $result = mysqli_query($bdd, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        
        // Affichez le formulaire de modification, pré-rempli avec les données actuelles de l'événement
        echo "<form method='post' action='' enctype='multipart/form-data'>";
        echo "<input type='hidden' name='idevenement' value='" . $row['idevenement'] . "'>";
        echo "Titre: <input type='text' name='titre' value='" . $row['titre'] . "'><br>";
        echo "Sous-titre: <input type='text' name='soustitre' value='" . $row['soustitre'] . "'><br>";
        echo "Description de l'événement: <textarea name='description_event'>" . $row['description_event'] . "</textarea><br>";
        echo "Description supplémentaire: <textarea name='description_info'>" . $row['description_info'] . "</textarea><br>";
        echo "Image actuelle: <img src='../" . $row['image'] . "' alt='Image actuelle de l'événement' width='100' height='100'><br>";
        echo "Nouvelle image: <input type='file' name='image'><br>";
        echo "<input type='submit' value='Modifier'>";
        echo "</form>";
    } else {
        echo "Événement non trouvé.";
    }
} else {
    echo "ID de l'événement non spécifié.";
}

mysqli_close($bdd);
?>
