<?php
session_start();
include("bdconnect.php");

// Récupérer le nom d'utilisateur actuellement connecté
$utilisateur = $_SESSION['utilisateur'];

// Déclarer des variables pour stocker les informations de l'utilisateur
$email = "";
$motdepasse = "";

// Requête SQL pour récupérer les informations de l'utilisateur
$requete = "SELECT email, motdepasse FROM admin WHERE admin = ?";
$stmt = mysqli_prepare($bdd, $requete);
mysqli_stmt_bind_param($stmt, "s", $utilisateur);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $email, $motdepasse);

// Récupérer les informations de l'utilisateur
mysqli_stmt_fetch($stmt);

// Fermer la requête
mysqli_stmt_close($stmt);

// Fonction pour afficher un message d'erreur
function afficherErreur($message) {
    echo '<div class="erreur">' . $message . '</div>';
}

// Fonction pour afficher un message de succès
function afficherSucces($message) {
    echo '<div class="succes">' . $message . '</div>';
}

// Vérifier si le formulaire a été soumis pour mettre à jour les informations
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nouveauEmail = $_POST["email"];
    $nouveauMotdepasse = $_POST["nouveau_motdepasse"];

    // Valider et mettre à jour les données de l'utilisateur
    if (!empty($nouveauEmail)) {
        // Mettre à jour l'email
        $requeteUpdate = "UPDATE admin SET email = ? WHERE admin = ?";
        $stmtUpdate = mysqli_prepare($bdd, $requeteUpdate);
        mysqli_stmt_bind_param($stmtUpdate, "ss", $nouveauEmail, $utilisateur);
        
        if (mysqli_stmt_execute($stmtUpdate)) {
            afficherSucces("Email mis à jour avec succès.");
            $email = $nouveauEmail; // Mettre à jour la variable d'affichage
        } else {
            afficherErreur("Erreur lors de la mise à jour de l'email : " . mysqli_error($bdd));
        }
        mysqli_stmt_close($stmtUpdate);
    }

    if (!empty($nouveauMotdepasse)) {
        // Mettre à jour le mot de passe (vous devrez ajouter la logique de hachage appropriée ici)
        // Assurez-vous de hacher le nouveau mot de passe avant de le stocker dans la base de données
        // Exemple : $motdepasseHache = password_hash($nouveauMotdepasse, PASSWORD_DEFAULT);
        
        $requeteUpdateMotdepasse = "UPDATE admin SET motdepasse = ? WHERE admin = ?";
        $stmtUpdateMotdepasse = mysqli_prepare($bdd, $requeteUpdateMotdepasse);
        mysqli_stmt_bind_param($stmtUpdateMotdepasse, "ss", $motdepasseHache, $utilisateur);
        
        if (mysqli_stmt_execute($stmtUpdateMotdepasse)) {
            afficherSucces("Mot de passe mis à jour avec succès.");
        } else {
            afficherErreur("Erreur lors de la mise à jour du mot de passe : " . mysqli_error($bdd));
        }
        mysqli_stmt_close($stmtUpdateMotdepasse);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Profil de l'administrateur</title>
   <link rel="stylesheet" href="style/admin_css.css">
</head>
<body>
   
<div class="container">
   <div class="content">
      <h3>Bonjour, <span>Admin</span></h3>
      <h1>Bienvenue <span><?php echo $_SESSION['utilisateur']; ?></span></h1>
      <p>Que souhaitez-vous faire ?</p>
      <a href="profil_admin.php" class="btn">Gestion du profil</a>
      <a href="register_form.php" class="btn">Gestion demande d'essai</a>
      <a href="login_form.php" class="btn">Gestion voiture</a>
      <a href="register_form.php" class="btn">Gestion événement</a>
      <a href="logout.php" class="btn">Déconnexion</a>
   </div>
   <div class="profil">
      <h2>Profil de l'administrateur</h2>
      <form action="" method="post">
         <label for="email">Adresse email :</label>
         <input type="email" name="email" value="<?php echo $email; ?>" required>
         
         <label for="nouveau_motdepasse">Nouveau mot de passe :</label>
         <input type="password" name="nouveau_motdepasse">
         
         <input type="submit" name="submit" value="Mettre à jour le profil" class="form-btn">
      </form>
   </div>
</div>

</body>
</html>
