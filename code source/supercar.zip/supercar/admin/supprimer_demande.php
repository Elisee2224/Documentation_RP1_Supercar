<?php
include("bdconnect.php"); // Assurez-vous que cette ligne inclut la connexion à la base de données.

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Supprimez la demande d'essai de la base de données
    $requete = "DELETE FROM demande_essai WHERE idessai = $id";
    $resultat = mysqli_query($bdd, $requete);
    
    if ($resultat) {
        echo "Demande d'essai supprimée avec succès.";
    } else {
        echo "Erreur lors de la suppression de la demande d'essai : " . mysqli_error($bdd);
    }
} else {
    echo "ID de demande d'essai non spécifié.";
}

mysqli_close($bdd); // Fermez la connexion à la base de données
?>
