<?php
include("bdconnect.php");

// Vérifiez si l'ID de l'événement à supprimer a été passé dans l'URL
if (isset($_GET['id'])) {
    $idevenement = $_GET['id'];
    
    // Exécutez une requête SQL pour supprimer l'événement
    $sql = "DELETE FROM evenement WHERE idevenement = $idevenement";
    if (mysqli_query($bdd, $sql)) {
        echo "Événement supprimé avec succès.";
    } else {
        echo "Erreur lors de la suppression de l'événement : " . mysqli_error($bdd);
    }
} else {
    echo "ID de l'événement non spécifié.";
}

mysqli_close($bdd);
?>
