<?php
include("bdconnect.php");

// Check if the voiture ID to delete is provided in the URL
if (isset($_GET['id'])) {
    $idvoiture = $_GET['id'];
    
    // Execute an SQL query to delete the voiture
    $sql = "DELETE FROM voitures WHERE idvoiture = $idvoiture";
    if (mysqli_query($bdd, $sql)) {
        echo "Voiture supprimée avec succès.";
    } else {
        echo "Erreur lors de la suppression de la voiture : " . mysqli_error($bdd);
    }
} else {
    echo "ID de la voiture non spécifié.";
}

mysqli_close($bdd);
?>
